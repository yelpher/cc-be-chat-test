const inquirer = require('inquirer');
var ws = require("ws");

function send_login_msg(sock,name){
	var msg = {cmd:"LOGIN",name:name};
	var msgStr = JSON.stringify(msg)
	sock.send(msgStr);
}

function send_chat_msg(sock,str){
	var msg = {cmd:"CHAT",content:str};
	var msgStr = JSON.stringify(msg)
	sock.send(msgStr);
}

function fomat_out_time(millsecs){
	var left = parseInt(millsecs/1000);
	var days = parseInt(left/86400);
	left = left%86400;
	var hours = parseInt(left/3600);
	left = left%3600;
	var mins = parseInt(left/60);
	var secs = left%60;

	// console.log("str:",days,hours,mins,secs);
	var str = "0000";
	str = str+days;
	var out_str = "";
	out_str += str.substr(str.length-2)+"d ";
	str = "0000"+hours;
	out_str += str.substr(str.length-2)+"h ";
	str = "0000"+mins;
	out_str += str.substr(str.length-2)+"m ";
	str = "0000"+secs;
	out_str += str.substr(str.length-2)+"s";
	console.log(out_str);
}
 
const run = async () => {
	const { name } = await askName();
	// url ws://127.0.0.1:6080
	// 创建了一个客户端的socket,然后让这个客户端去连接服务器的socket
	var sock = new ws("ws://127.0.0.1:6080");
	sock.on("open", function () {
		console.log("connect success !!!!");
		send_login_msg(sock,name);
	});
	 
	sock.on("error", function(err) {
		console.log("error: ", err);
	});
	 
	sock.on("close", function() {
		console.log("close");
	});
	 
	sock.on("message", function(data) {
		var msg = JSON.parse(data);
		console.log(msg);
		if( msg.cmd == "HISTORY" ){
			var chatHistory = JSON.parse(msg.str);
			chatHistory.map(function(chatInfo){
				console.log(`${chatInfo.name}: `, chatInfo.content);
			});
		}
		if( msg.cmd == "CHAT" ){
			console.log(`${msg.name}: `, msg.content);
		}
		if( msg.cmd == "LOGIN_TIME"){
			// console.log(msg.millsecs);
			fomat_out_time(msg.millsecs);
		}
		if( msg.cmd == "POPULAR"){
			console.log(msg.word);
		}
	});

	while (true) {
	  const answers = await askChat();
	  const { message } = answers;
	  send_chat_msg(sock,message);
	}
  };
  
  const askChat = () => {
	const questions = [
	  {
		name: "message",
		type: "input",
		message: "Enter chat message:"
	  }
	];
	return inquirer.prompt(questions);
  };
  
  const askName = () => {
	const questions = [
	  {
		name: "name",
		type: "input",
		message: "Enter your name:"
	  }
	];
	return inquirer.prompt(questions);
  };
  
  run();
