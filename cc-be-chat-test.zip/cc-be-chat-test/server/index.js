
// 加载node上websocket模块 ws;
var ws = require("ws");
var fs = require("fs");

const inquirer = require('inquirer');

var globalUserList = new Array();
var globalUserId = 0;
var globalFilterArray = new Array();
var globalChatHistory = new Array();
const ChatHistoryLength = 50;
// 最近5秒聊天记录
var globalChatHistory5S = new Array();
const ChatPeriodTime = 5000;

function load_filter_words(fileName){
	var promise = new Promise(function (resolve, reject) {
	  fs.readFile("server/data/list.txt", 'utf-8', (err, data) => {
		if (err) {
		  console.log("err",err)
		  throw err;
		}
		var str = data.toString();
		var array = str.split("\n");
		array.map(function(item){
		//console.log("i:",item)
		})
		resolve(array);
	  });
	});
	promise.then(function(filterList){
		filterList.map(function(filterWord){
			globalFilterArray.push(filterWord)
		})
	});
  }
  
  function check_chat_string (str) {
	var filterString = str;
	// console.log("check_chat_string:",globalFilterArray)
	return new Promise(function (resolve, reject) {
		globalFilterArray.map(function(filterWord){
			var filterRule= /[0-9a-zA-Z_]/g; 
			var replaceWord = filterWord.replace(filterRule,"*");
			//console.log("word,replace",filterWord,replaceWord);
			filterString = filterString.replace(new RegExp(filterWord,'g'),replaceWord);
	  });
	  resolve(filterString);
	});
  }

  // 清楚5S之后的记录
  const timeoutObj = setInterval(() => {
	while( globalChatHistory5S.length > 0 ){
		var chatInfo = globalChatHistory5S.shift();
		// console.log("chat info",chatInfo);
		if(chatInfo.createTime+ChatPeriodTime<Date.now()){
			console.log("remove chat info",chatInfo);
			
			// console.log("length",globalChatHistory5S.length);
		}
		else{
			globalChatHistory5S.unshift(chatInfo);
			break;
		}
	  }
  }, 1000);

const run = async () => {
	load_filter_words("server/data/list.txt");

	// 启动基于websocket的服务器,监听我们的客户端接入进来。
	var server = new ws.Server({
		host: "127.0.0.1",
		port: 6080,
	});

	// connection 事件, 有客户端接入进来;
	function on_server_client_comming (client_sock) {
		console.log("client comming");
		addUserInfo(client_sock)
		// console.log("client comming",globalUserList);
	}
	 
	server.on("connection", on_server_client_comming);
	
	// error事件,表示的我们监听错误;
	function on_server_listen_error(err) {
	 
	}
	server.on("error", on_server_listen_error);
	 
	// headers事件, 回给客户端的字符。
	function on_server_headers(data) {
		// console.log(data);
	}
	server.on("headers", on_server_headers);

	console.log("server started.");

	// while (true) {
	//   const commands = await askCommand();
	//   const { command } = commands;
	//   doCommand(command)
	// }
};

// 监听接入进来的客户端事件
function websocket_add_listener(client_sock) {
	// close事件
	client_sock.on("close", function() {
		console.log("client close");
		removeUserInfo(client_sock)
	});
 
	// error事件
	client_sock.on("error", function(err) {
		console.log("client error", err);
		removeUserInfo(client_sock)
	});
	// end 
 
	// message 事件, data已经是根据websocket协议解码开来的原始数据；
	// websocket底层有数据包的封包协议，所以，绝对不会出现粘包的情况。
	// 每解一个数据包，就会触发一个message事件;
	// 不会出现粘包的情况，send一次，就会把send的数据独立封包。
	// 如果我们是直接基于TCP，我们要自己实现类似于websocket封包协议就可以完全达到一样的效果；
	client_sock.on("message", function(data) {
		var msg = JSON.parse(data);
		console.log(msg);
		if( msg.cmd == "LOGIN" ){
			var promise = getUserInfo(client_sock);
			promise.then(function(userInfo){
				userInfo.name = msg.name;
				userInfo.loginTime = Date.now();
			});
			sendChatHistory(client_sock);
		}
		if( msg.cmd == "CHAT" ){
			if( msg.content.length > 0 ){
				if( execCommand(client_sock,msg.content) ){

				}
				else
				{
					var promise = getUserInfo(client_sock);
					promise.then(function(userInfo){
						var promise = check_chat_string(msg.content);
						  promise.then(function(str){
							broadcastChat(userInfo.name,str);
							addChatHistory(userInfo.name,str);
						  });
					});
				}
			}
		}
	});
	// end 
}

function addUserInfo(conn){
	++globalUserId;
	var userInfo = {id:globalUserId,name:"",loginTime:0,conn:conn};
	globalUserList.push(userInfo);
	websocket_add_listener(conn);
	console.log("current online:",globalUserList.length);
}

function removeUserInfo(conn){
	for(var i = 0; i < globalUserList.length; i++){
		if(globalUserList[i].conn == conn){
			globalUserList.splice(i, 1);
		}
	}	 
	console.log("current online:",globalUserList.length); 
}

function getUserInfo(conn){
	return new Promise(function (resolve, reject) {
		globalUserList.some(function(userInfo){
			if( userInfo.conn == conn ){
				resolve(userInfo);
			}
		  })
		});
}

function getUserInfoByName(name){
	return new Promise(function (resolve, reject) {
		globalUserList.some(function(userInfo){
			if( userInfo.name == name ){
				resolve(userInfo);
			}
		  })
		});
}

function addWordCount(wordsCountArray,word){
	var isExist = false;
	wordsCountArray.map(function(wordInfo){
		if( word == wordInfo.word ){
			++wordInfo.count;
			isExist = true;
			return true;
		}
	});
	if( !isExist ){
		var wordInfo = {word:word,count:1};
		wordsCountArray.push(wordInfo);
	}
}

function getMostPopularWord(){
	return new Promise(function (resolve, reject) {
		var wordsCountArray=new Array();
		globalChatHistory5S.map(function(chatInfo){
			var words = chatInfo.content.split(" ");
			words.map(function(word){
				addWordCount(wordsCountArray,word);
			})
		});
		var mostPopularCount = 0;
		var mostPopularWord = "";
		wordsCountArray.map(function(wordInfo){
			if( wordInfo.count > mostPopularCount ){
				mostPopularCount = wordInfo.count;
				mostPopularWord = wordInfo.word;
			}
		});
		resolve(mostPopularWord);
	});
}

function addChatHistory(name,content){
	var chatInfo = {name:name,content:content,createTime:Date.now()};
	globalChatHistory.push(chatInfo);
	globalChatHistory5S.push(chatInfo);
	if( globalChatHistory.length > ChatHistoryLength ){
		globalChatHistory.pop();
	}				
}

function sendChatHistory(conn){
	var msg = {cmd:"HISTORY",str:JSON.stringify(globalChatHistory)};
	var msgStr = JSON.stringify(msg)
	conn.send(msgStr);
}

function sendPopular(conn){
	var promise = getMostPopularWord();
	promise.then(function(word){
		var msg = {cmd:"POPULAR",word:word};
		var msgStr = JSON.stringify(msg)
		conn.send(msgStr);
	})
}

function sendLoginTime(conn,millsecs){
	var msg = {cmd:"LOGIN_TIME",millsecs:millsecs};
	var msgStr = JSON.stringify(msg)
	conn.send(msgStr);
}

function broadcastChat(name,content){
	var msg = {cmd:"CHAT",name:name,content:content};
	var msgStr = JSON.stringify(msg)
	globalUserList.map(function(userInfo){
		if( userInfo.loginTime>0 ){
			userInfo.conn.send(msgStr);
		}
	});
}

function execCommand(conn,commandString){
	var c = commandString.substring(0,1);
	if( c != "/"){
	  return false;
	}
	var s = commandString.substring(1);
	var params = s.split(" ");
	if( params.length < 1 ){
	  return false;
	}
	var command = params[0];
	if( command == "popular" ){
	  sendPopular(conn);
	  return true;
	}
	if( command == "stats"){
	  if( params.length < 2 ){
		var promise = getUserInfo(conn);
	  	promise.then(function(userInfo){
		  var millsecs = Date.now()-userInfo.loginTime;
		  sendLoginTime(conn,millsecs);
		});
	  }
	  else
	  {
		var promise = getUserInfoByName(params[1]);
		promise.then(function(userInfo){
			var millsecs = Date.now()-userInfo.loginTime;
			sendLoginTime(conn,millsecs);
		});
	  }
	  return true;
	}
	return false;
  }

run();