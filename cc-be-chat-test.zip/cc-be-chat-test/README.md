需要npm install ws
引入fs，用于读入屏蔽词
引入ws，用于网络通信

服务器启动方式：
打开cmd，进入到cc-be-chat-test目录，执行node server/index.js

客户端启动方式：
打开cmd，进入到cc-be-chat-test目录，执行node client/index.js

指令说明：
/popular 打印最近5秒钟最受欢迎的词
/stats [username] 打印在线时长，不填username打印自己在线时长

时间比较紧，没来得及整理模块和处理细节，请见谅！